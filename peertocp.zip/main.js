const {app, BrowserWindow, ipcMain} = require('electron');
const path = require('path');
const fs = require('fs')
const pty = require("node-pty");
const os = require("os");
const crypto = require('crypto');
const SHELL_PREFERENCE = {
  "win32": "cmd.exe", "linux": "bash", "darwin": "zsh"
}
const shell = SHELL_PREFERENCE[os.platform()] || "bash"
let mainWindow;

/*
Start Of Processes and Compilers Code
 */

const processMap = new Map()

const runFile = (compileResultfile, id) => {
  const startTime = new Date()
  const ptyProcess = pty.spawn(compileResultfile, [], {
    name: "xterm-color",
    cols: 80,
    rows: 30,
    cwd: path.join(process.env.HOME, 'p2cp'),
    env: process.env
  });
  processMap.set(id, ptyProcess)
  const updateTerminalData = (data) => {
    mainWindow.webContents.send("terminal.update", id, data);
  }
  ptyProcess.onData(data => {
    updateTerminalData([data])
  });
  ptyProcess.onExit(data => {
    updateTerminalData([``])
    updateTerminalData([`[PeerToCP: Exited with code ${data.exitCode}]\r\n`])
    updateTerminalData([`[PeerToCP: Signal ${data.signal}]\r\n`])
    updateTerminalData(
        [`[PeerToCP: Finished Running in ${((new Date()) - startTime)
        / 1000}s]\r\n`])
  })
  // ipcMain.on(`terminal.keystroke.${id}`, (event, key) => {
  //   ptyProcess.write(key);
  // });
  // ipcMain.on(`terminal.kill.${id}`, () => {
  //   ptyProcess.kill()
  // })
}

const compileHandler = (event, source, code) => {
  const p2cpdir = path.join(process.env.HOME, 'p2cp')
  const codefile = path.join(p2cpdir, 'code.cpp')
  const compileResultfile = path.join(p2cpdir, 'code')
  if (!fs.existsSync(p2cpdir)) {
    fs.mkdir(p2cpdir, (err) => {
      if (err) {
        console.log(err)
      }
    });
  }
  fs.writeFile(codefile, code, err => {
    if (err) {
      console.log(err)
    }
  })
  const sendBack = (message, isReplace = false) => {
    mainWindow.webContents.send("message.send", source, JSON.stringify({
      type: isReplace ? "compile.replace" : "compile.append", message: message
    }))
  }
  sendBack("Compiling...\n", true)
  const compileProcess = pty.spawn("g++", [codefile, "-o", compileResultfile],
      {})
  compileProcess.onData(data => {
    sendBack(data)
  })
  compileProcess.onExit(data => {
    sendBack(`Exited with code ${data.exitCode}`)
    if (data.exitCode === 0) {
      const uuid = crypto.randomUUID()
      mainWindow.webContents.send("terminal.uuid", uuid)
      runFile(compileResultfile, uuid)
    }
  })
}

/*
End Of Compilers Code
 */

let terminalWin;

const openTerminalHandler = (event, id) => {
  if (terminalWin && !terminalWin.isDestroyed()) {
    return;
  }
  terminalWin = new BrowserWindow({
    width: 800, height: 400, webPreferences: {
      nodeIntegration: true, contextIsolation: false,
    }
  })
  let loaded = false;
  terminalWin.loadFile(path.join('renderer', 'terminal.html'))
  terminalWin.webContents.once('did-finish-load', () => {
    mainWindow.webContents.send("terminal.subscribe", id)
  })
  terminalWin.on('closed', () => {
    mainWindow.webContents.send("terminal.unsubscribe", id)
  })
}

const receiveSubscribedHandler = (event, accumulated) => {
  if (!terminalWin || terminalWin.isDestroyed()) {
    return;
  }
  terminalWin.webContents.send("terminal.incomingData", accumulated)
}

const keystrokeHandler = (event, e) => {
  mainWindow.webContents.send(
      "message.send",
      "active-terminal",
      { type: "shell.keystroke", keystroke: e }
  )
}

const receiveKeystrokeHandler = (event, terminalId, keystroke) => {
  const myProcess = processMap.get(terminalId)
  myProcess.write(keystroke);
}

const createWindow = () => {
  mainWindow = new BrowserWindow({
    width: 800, height: 600, webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    }
  })
  mainWindow.loadFile(path.join('renderer', 'index.html'))
}

app.commandLine.appendSwitch('ignore-certificate-errors');
app.commandLine.appendSwitch('enable-quic');
app.commandLine.appendSwitch('origin-to-force-quic-on', '127.0.0.1:3000');

app.whenReady().then(() => {
  createWindow()
  console.log(app.commandLine.hasSwitch('origin-to-force-quic-on'))

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    }
  })
  ipcMain.on('compile.request', compileHandler)
  ipcMain.on('terminal.window.add', openTerminalHandler)
  ipcMain.on('terminal.keystroke.send', keystrokeHandler)
  ipcMain.on('terminal.keystroke.receive', receiveKeystrokeHandler)
  ipcMain.on('terminal.message.receive', receiveSubscribedHandler)
})

app.on('window-all-closed', () => {
  if (process.platform !== "darwin") {
    app.quit()
  }
})

/*app.on('certificate-error', (event, webContents, url, error, certificate, callback) => {
    // On certificate error we disable default behaviour (stop loading the page)
    // and we then say "it is all fine - true" to the callback
    event.preventDefault();
    callback(true);
});*/
